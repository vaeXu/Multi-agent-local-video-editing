# 剪辑阶段契约

本阶段只拥有 `剧集/<EP>/剪辑单.md`（交付规格与 `CUT-...` 条目）及 `剧集/<EP>/制作成果/成片/` 下的渲染产物，不回写《剧本.md》《视觉设定.md》《分镜.md》或《视频提示词.md》。

## 本阶段规则

### `EDT`

| ID | Class | Knowledge |
|---|---|---|
| EDT-01 | structural_invariant | Every `CUT-...` binds one existing source item and one currently readable media file: `MOTION-...` for video, or `SHOT-...` / `IMG-...` for a still. A cut with no material source cannot exist. |
| EDT-02 | structural_invariant | 入点, 出点 and 时长 are self-consistent (`出点 - 入点 == 时长`) and non-negative. A video's 出点 does not exceed its measured source duration; a still starts at 0 and has 出点 equal to its declared 时长 of at least 0.50 seconds. |
| EDT-03 | structural_invariant | Editing selects and orders existing frames. It never rewrites dialogue, shot purpose, start/end state, or any upstream declared duration; a needed semantic change is reported to the owning document instead. |
| EDT-04 | reviewed_invariant | Dialogue retained in the film remains audibly complete. Picture may cut during a line if the sound remains continuous and the narrative is clear. The built-in renderer trims a video's original audio with its picture, while independent 配音 files may cross cuts; extracting or replacing the video's original audio requires an external tool. |
| EDT-05 | structural_invariant | When subtitles are requested, every retained spoken line has a cue copied verbatim, including punctuation, from the screenplay into the cut list. Rendering may transform punctuation for display. Transcription locates speech but does not replace the source text. |
| EDT-06 | structural_invariant | Two cuts drawn from the same video do not overlap in source time. Deliberate video repetition is declared and states why the second appearance still earns its place. A still image may be reused across cuts. |
| EDT-07 | reviewed_invariant | Each cut's in-point and out-point land inside that material's usable band, and 取舍 names what is visible at each boundary rather than citing an abstract need for pace. |
| EDT-08 | craft_default | Check adjacent cuts for unintended visual jumps and duplicated information. Similar framing, deliberate repetition and jump cuts are valid when they serve the accepted narrative. |
| EDT-09 | craft_default | Do not mechanically redistribute trimmed time. Extend another beat only when its performance or readability benefits, and preserve explicit delivery-duration requirements. |
| EDT-10 | reviewed_invariant | Listen to joins for unintended changes in ambience or music. Use an appropriate documented audio treatment when needed; the built-in renderer does not execute prose mixing instructions. |
| EDT-11 | reviewed_invariant | Record unused shots with a reason: missing material, unusable quality, or an intentional narrative omission. |
| EDT-12 | craft_default | Normalize the delivered film to one declared loudness target (default tolerance ±1 LU, true peak ≤ -1.5 dBTP unless overridden on `交付响度`) with burned subtitles by default; report measured integrated loudness and true peak, or stop and report the gap after one external treatment so the creator can accept or revise. |
| EDT-13 | craft_default | Distinguish a reference target from a required delivery duration. Report the gap and satisfy a fixed requirement or identify the material needed to do so. |
| EDT-14 | taste_option | Cut rhythm, whether a beat is held or clipped, and whether a moment repeats are creator choices; the suite records them and does not treat any of them as defects. |
| EDT-15 | structural_invariant | Rendering, duration match and file existence are technical outcomes. None of them may be reported as a statement about whether the film is good; quality goes to review or to the creator. |
| EDT-16 | reviewed_invariant | Compare shots within the same scene and lighting state using comparable image regions. Record corrections, then inspect the output. Whole-frame averages alone do not establish a mismatch; intentional lighting changes are valid. |
| EDT-17 | structural_invariant | After material is regenerated, re-measure the spoken spans and update its subtitle windows before rendering. The material-mtime warning is a prompt to check, not proof of alignment. |
| EDT-18 | taste_option | Optional grain is declared once in the delivery spec and applied dynamically after assembly by the built-in renderer. Its supported range is a tool limit, not a quality standard; other treatments may use external grading tools. |
| EDT-19 | craft_default | A dialogue cut enters about 0.25 s before the line's speech onset and leaves about 0.4 s after the line ends, and lasts at least about 1.2 s. Locate these from the sounds that belong to the scripted line, so noise never stretches the cut. |
| EDT-20 | craft_default | Within one scene, the built-in renderer pulls each cut partway toward the scene's median exposure and colour and reports the values it applied. A cut's stated correction or 「不校」 replaces the automatic match, and the delivery spec can turn it off. |
| EDT-21 | craft_default | Split multi-shot fight clips at generated shot boundaries and trim static head/tail holds so cuts land mid-motion (impact close-up ~0.3–0.5 s through hit, wind-up only what reads as effort, aftermath until receiver's state reads). |
| EDT-22 | craft_default | When a line provokes a reaction or multi-person exchange, cut to the listener before the line ends (L-cut) or lead with the next voice (J-cut) instead of holding 0.4 s after the line; carry the overhanging audio across the cut via an extracted `配音` clip while keeping the subtitle on the speaker's cut. |
| EDT-23 | craft_default | `verify` lists cuts where RMS sound level (~0.4 s each side) jumps by > 10 dB as a listening prompt under EDT-10, never as a blocking gate. |
